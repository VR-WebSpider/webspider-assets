import { LockManager, LocalStorageDriver, WebSpiderAIService } from '@webspider/core';
import * as os from 'os';

const driver = new LocalStorageDriver('./.webspider_store');
const lockManager = new LockManager({
  secretKey: process.env.WEBSPIDER_SECRET || 'webspider_super_secret_key_2026'
});
const aiService = new WebSpiderAIService();

const TOOLS = [
  {
    name: 'vcs_status',
    description: 'Get WebSpider VCS active exclusive locks, workspace modification status, and cloud sync info.',
    inputSchema: { type: 'object', properties: {} }
  },
  {
    name: 'vcs_lock_file',
    description: 'Acquire exclusive lock on a binary asset to prevent parallel edits by team members.',
    inputSchema: {
      type: 'object',
      properties: {
        assetPath: { type: 'string', description: 'Path to asset file (e.g. Assets/Art/Character.uasset)' },
        ownerName: { type: 'string', description: 'Developer name' },
        engineName: { type: 'string', description: 'Engine (Unity, Unreal, Godot, etc.)' }
      },
      required: ['assetPath']
    }
  },
  {
    name: 'vcs_unlock_file',
    description: 'Release an active exclusive lock on an asset.',
    inputSchema: {
      type: 'object',
      properties: {
        assetPath: { type: 'string', description: 'Path to asset file to release' }
      },
      required: ['assetPath']
    }
  },
  {
    name: 'vcs_force_break_lock',
    description: 'Force unlock an asset held by an offline user or deadlock, logging an immutable audit record.',
    inputSchema: {
      type: 'object',
      properties: {
        assetPath: { type: 'string', description: 'Path to asset file' },
        reason: { type: 'string', description: 'Reason for force unlocking' }
      },
      required: ['assetPath', 'reason']
    }
  },
  {
    name: 'vcs_ai_assist',
    description: 'Use WebSpider AI (local Ollama or cloud Gemini/OpenAI) to generate commit messages or advice on binary conflicts.',
    inputSchema: {
      type: 'object',
      properties: {
        task: { type: 'string', enum: ['smart_commit', 'conflict_advice', 'asset_summary'] },
        assetPath: { type: 'string' }
      },
      required: ['task']
    }
  }
];

async function handleToolCall(name: string, args: any) {
  const currentUser = process.env.USER || process.env.USERNAME || 'AI_Assistant';
  const currentHost = os.hostname();

  switch (name) {
    case 'vcs_status': {
      const locks = lockManager.getAllLocks();
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(
              {
                system: 'WebSpider VCS MCP Server',
                host: currentHost,
                activeLockCount: locks.length,
                locks
              },
              null,
              2
            )
          }
        ]
      };
    }
    case 'vcs_lock_file': {
      const { assetPath, ownerName, engineName } = args;
      const res = await lockManager.acquireLock(assetPath, currentUser, ownerName || currentUser, currentHost, engineName || 'MCP');
      return {
        content: [
          {
            type: 'text',
            text: res.success
              ? `✅ Locked "${assetPath}" exclusively. Lease Token: ${res.lock?.leaseToken}`
              : `❌ Lock failed: ${res.error}`
          }
        ]
      };
    }
    case 'vcs_unlock_file': {
      const { assetPath } = args;
      const res = await lockManager.releaseLock(assetPath, currentUser);
      return {
        content: [
          {
            type: 'text',
            text: res.success ? `🔓 Released lock on "${assetPath}".` : `❌ Unlock failed: ${res.error}`
          }
        ]
      };
    }
    case 'vcs_force_break_lock': {
      const { assetPath, reason } = args;
      const res = await lockManager.forceBreakLock(assetPath, currentUser, reason);
      return {
        content: [
          {
            type: 'text',
            text: res.success ? `⚠️ Force unlocked "${assetPath}". Security audit log created.` : `❌ Force break failed: ${res.error}`
          }
        ]
      };
    }
    case 'vcs_ai_assist': {
      const { task, assetPath } = args;
      if (task === 'smart_commit') {
        const msg = await aiService.generateCommitMessage([
          { assetPath: assetPath || 'Assets/Scene/MainLevel.unity', action: 'modify', sizeBytes: 8500000 }
        ]);
        return { content: [{ type: 'text', text: msg }] };
      } else if (task === 'conflict_advice') {
        const advice = await aiService.suggestConflictResolution(assetPath || 'Assets/Player.uasset', 'Alex', 'Sarah', []);
        return { content: [{ type: 'text', text: advice }] };
      } else {
        const summary = await aiService.summarizeAssetChanges(assetPath || 'Assets/Model.fbx', '3D Model');
        return { content: [{ type: 'text', text: summary }] };
      }
    }
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

// Simple JSON-RPC standard reader for standard MCP stdio integration
process.stdin.on('data', async data => {
  try {
    const lines = data.toString().split('\n').filter(l => l.trim().length > 0);
    for (const line of lines) {
      const req = JSON.parse(line);
      if (req.method === 'tools/list') {
        process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: req.id, result: { tools: TOOLS } }) + '\n');
      } else if (req.method === 'tools/call') {
        const result = await handleToolCall(req.params.name, req.params.arguments);
        process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: req.id, result }) + '\n');
      }
    }
  } catch (err: any) {
    // Silently process valid JSON-RPC frames
  }
});

console.error('🕷️ WebSpider VCS MCP Server running on stdio');
