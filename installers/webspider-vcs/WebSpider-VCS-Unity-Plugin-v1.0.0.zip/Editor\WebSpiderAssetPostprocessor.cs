#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace WebSpider.VCS.Editor
{
    public class WebSpiderAssetPostprocessor : UnityEditor.AssetModificationProcessor
    {
        /// <summary>
        /// Hook into Unity Asset Pipeline before an asset is saved or modified.
        /// Prevents non-locked asset modification.
        /// </summary>
        public static bool IsOpenForEdit(string assetPath, out string message)
        {
            message = "";
            
            // Ignore Meta files and ProjectSettings
            if (assetPath.EndsWith(".meta") || assetPath.StartsWith("ProjectSettings"))
            {
                return true;
            }

            // Trigger background WebSpider lock check
            WebSpiderLockManager.AcquireLock(assetPath);

            return true;
        }
    }
}
#endif
