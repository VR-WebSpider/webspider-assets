#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace WebSpider.VCS.Editor
{
    public class WebSpiderWindow : EditorWindow
    {
        [MenuItem("Window/WebSpider VCS")]
        public static void ShowWindow()
        {
            GetWindow<WebSpiderWindow>("WebSpider VCS");
        }

        private void OnGUI()
        {
            GUILayout.Label("🕷️ WebSpider Version Control", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Exclusive Asset Locking & Cloud Sync for Unity Projects.", MessageType.Info);

            EditorGUILayout.Space();

            if (GUILayout.Button("🔒 Acquire Lock on Selected Asset", GUILayout.Height(30)))
            {
                var selected = Selection.activeObject;
                if (selected != null)
                {
                    string path = AssetDatabase.GetAssetPath(selected);
                    WebSpiderLockManager.AcquireLock(path);
                }
            }

            if (GUILayout.Button("🔓 Release Lock on Selected Asset", GUILayout.Height(30)))
            {
                var selected = Selection.activeObject;
                if (selected != null)
                {
                    string path = AssetDatabase.GetAssetPath(selected);
                    WebSpiderLockManager.ReleaseLock(path);
                }
            }
        }
    }
}
#endif
