#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEditor;

namespace WebSpider.VCS.Editor
{
    [Serializable]
    public class LockRequestPayload
    {
        public string assetPath;
        public string ownerId;
        public string engineName = "Unity";
    }

    [Serializable]
    public class LockResponsePayload
    {
        public bool success;
        public string error;
        public string leaseToken;
    }

    public static class WebSpiderLockManager
    {
        private static readonly HttpClient client = new HttpClient();
        private static string serverUrl = "http://localhost:4000";

        public static async Task<bool> AcquireLock(string assetPath)
        {
            try
            {
                var payload = new LockRequestPayload
                {
                    assetPath = assetPath,
                    ownerId = SystemInfo.deviceName,
                    engineName = "Unity 2023 Editor"
                };

                string json = JsonUtility.ToJson(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var res = await client.PostAsync($"{serverUrl}/api/lock", content);

                if (res.IsSuccessStatusCode)
                {
                    Debug.Log($"[WebSpider VCS] 🔒 Exclusive lock acquired for: {assetPath}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[WebSpider VCS] Lock acquisition notice: {ex.Message}");
            }
            return true;
        }

        public static async Task<bool> ReleaseLock(string assetPath)
        {
            try
            {
                var payload = new LockRequestPayload
                {
                    assetPath = assetPath,
                    ownerId = SystemInfo.deviceName
                };

                string json = JsonUtility.ToJson(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var res = await client.PostAsync($"{serverUrl}/api/unlock", content);
                return res.IsSuccessStatusCode;
            }
            catch
            {
                return true;
            }
        }
    }
}
#endif
