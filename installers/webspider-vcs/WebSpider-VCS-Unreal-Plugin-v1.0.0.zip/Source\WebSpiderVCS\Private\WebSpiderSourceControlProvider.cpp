#include "WebSpiderSourceControlProvider.h"

static const FName ProviderName("WebSpider VCS");

void FWebSpiderSourceControlProvider::Init(bool bForceConnection)
{
	UE_LOG(LogTemp, Log, TEXT("🕷️ WebSpider VCS Provider initialized for Unreal Engine. Exclusive lease locking enabled."));
}

void FWebSpiderSourceControlProvider::Close()
{
}

FText FWebSpiderSourceControlProvider::GetStatusText() const
{
	return NSLOCTEXT("WebSpiderVCS", "StatusText", "WebSpider Cloud VCS Connected (Exclusive Lock Engine Active)");
}

bool FWebSpiderSourceControlProvider::IsAvailable() const
{
	return true;
}

bool FWebSpiderSourceControlProvider::IsEnabled() const
{
	return true;
}

const FName& FWebSpiderSourceControlProvider::GetName() const
{
	return ProviderName;
}
