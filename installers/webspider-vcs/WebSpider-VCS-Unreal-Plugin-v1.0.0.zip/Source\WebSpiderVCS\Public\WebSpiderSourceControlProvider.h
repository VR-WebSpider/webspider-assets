#pragma once

#include "CoreMinimal.h"
#include "ISourceControlProvider.h"

/**
 * WebSpider Source Control Provider for Unreal Engine 5
 */
class FWebSpiderSourceControlProvider : public ISourceControlProvider
{
public:
	virtual void Init(bool bForceConnection = true) override;
	virtual void Close() override;
	virtual FText GetStatusText() const override;
	virtual bool IsAvailable() const override;
	virtual bool IsEnabled() const override;
	virtual const FName& GetName() const override;
	virtual bool UsesLocalReadOnlyState() const override { return true; }
	virtual bool UsesCheckout() const override { return true; }
};
