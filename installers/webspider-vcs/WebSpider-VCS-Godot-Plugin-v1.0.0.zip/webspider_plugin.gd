@tool
extends EditorPlugin

# WebSpider VCS Plugin for Godot 4.x
# Provides exclusive asset locking, cloud sync & AI commit integration

func _enter_tree():
	print("🕷️ WebSpider VCS Plugin Loaded in Godot 4 Editor")
	add_tool_menu_item("WebSpider: Acquire Asset Lock", _acquire_lock_menu)
	add_tool_menu_item("WebSpider: Release Asset Lock", _release_lock_menu)

func _exit_tree():
	remove_tool_menu_item("WebSpider: Acquire Asset Lock")
	remove_tool_menu_item("WebSpider: Release Asset Lock")

func _acquire_lock_menu():
	print("[WebSpider VCS] Acquiring exclusive lock lease for active scene...")

func _release_lock_menu():
	print("[WebSpider VCS] Releasing asset lock lease...")
